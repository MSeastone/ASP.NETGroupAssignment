﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Uppgift_asp.net_grupp_5.Migrations
{
    public partial class testing1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
