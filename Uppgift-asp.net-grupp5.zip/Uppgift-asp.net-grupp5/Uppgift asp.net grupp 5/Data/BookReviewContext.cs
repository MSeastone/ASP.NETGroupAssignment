﻿using Microsoft.EntityFrameworkCore;
using Uppgift_asp.net_grupp_5.Models;

namespace Uppgift_asp.net_grupp_5.Data
{
    public class BookReviewContext : DbContext
    {
        public BookReviewContext(DbContextOptions<BookReviewContext> options) : base(options)
        {

        }

        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Review> Reviews { get; set; }
    }
}
