﻿using Microsoft.AspNetCore.Mvc;

namespace Uppgift_asp.net_grupp_5.Controllers
{
    public class AboutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
