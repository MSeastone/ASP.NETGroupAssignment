﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.Linq;
using System.Threading.Tasks;
using Uppgift_asp.net_grupp_5.Data;
using Uppgift_asp.net_grupp_5.Models;

namespace Uppgift_asp.net_grupp_5.Controllers
{
    public class BooksController : Controller
    {
        private readonly BookReviewContext _context;

        public BooksController(BookReviewContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {

            var autors = _context.Authors;
            ViewBag.authorNames = autors;
            return View(await _context.Books.ToListAsync());
        }

        // GET: Books/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .FirstOrDefaultAsync(m => m.Id == id);
            if (book == null)
            {
                return NotFound();
            }

            var reviews = _context.Reviews;
            int count = 0;

            foreach (var temp in reviews)
            {
                if (temp.Book == null) continue;
                if (id == temp.BookId)
                {
                    count++;
                }
            }
            ViewBag.result = count;
            var authorNames = _context.Authors;
            foreach (var temp in authorNames)
            {
                if (temp.Id == id)
                {
                    ViewBag.authorNames = temp.AuthorName;
                }
            }
            return View(book);
        }

        // GET: Books/Create
        public IActionResult Create()
        {
            var myViewModel = new ViewModel();
            myViewModel.Authors = new SelectList(GetAuthors(), "Id", "AuthorName");
            //Book.AuthorList = _context.Authors.ToList();
            return View(myViewModel);
        }

        private IEnumerable GetAuthors()
        {
            var allAuthors = _context.Authors.Select(a => a);
            return allAuthors;
        }

        // POST: Books/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,AuthorId,Genre,Year")] Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        // GET: Books/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // POST: Books/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,AuthorId,Genre,Year")] Book book)
        {
            if (id != book.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(book);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        // GET: Books/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Books
                .FirstOrDefaultAsync(m => m.Id == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Books.FindAsync(id);
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BookExists(int id)
        {
            return _context.Books.Any(e => e.Id == id);
        }
        public async Task<IActionResult> Review(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            var reviews = from b in _context.Books
                       from r in _context.Reviews
                       where r.BookId == b.Id && r.BookId == id
                       select r;
            //foreach (var review in reviews)
            //{
            //    ViewBag.result = review.ReviewText;
            //}
            ViewBag.result = reviews;
            return View(book);
        }
    }
}
