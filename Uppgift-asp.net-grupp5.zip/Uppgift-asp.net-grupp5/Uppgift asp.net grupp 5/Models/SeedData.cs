﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using Uppgift_asp.net_grupp_5.Data;

namespace Uppgift_asp.net_grupp_5.Models
{
    public class SeedData
    {
        public static void Seed(IServiceProvider serviceProvider)
        {
            using (var context = new BookReviewContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<BookReviewContext>>()))
            {
                // Look for any movies.
                if (context.Books.Any())
                {
                    return;   // DB has been seeded
                }
                if (!context.Books.Any())
                {
                    var authors = new Author[]
                    {
                        new Author { AuthorName = "Stephen King" },
                        new Author { AuthorName = "Jules Verne" },
                        new Author { AuthorName = "J.R.R. Tolkien" },
                        new Author { AuthorName = "Neil deGrasse Tyson" },
                        new Author { AuthorName = "George R.R. Martin" },
                        new Author { AuthorName = "Astrid Lindgren" },
                        new Author { AuthorName = "H.P. Lovecraft" },
                        new Author { AuthorName = "Dan Brown" },
                        new Author { AuthorName = "J.K. Rowling" },
                        new Author { AuthorName = "Harper Lee" },
                    };

                    context.Authors.AddRange(authors);
                    context.SaveChanges();

                    var books = new Book[]
                    {
                        new Book { AuthorId = 1, Genre = "Horror", Title = "Misery", Year = 1999 },
                        new Book { AuthorId = 2, Genre = "Science Fiction", Title = "Journey to the Center of the Earth", Year = 1864 },
                        new Book { AuthorId = 3, Genre = "Fantasy", Title = "The Fellowship of the Ring", Year = 1954 },
                        new Book { AuthorId = 4, Genre = "Science & Engineering", Title = "Astrophysics for People in a Hurry", Year = 2017 },
                        new Book { AuthorId = 5, Genre = "Fantasy", Title = "A Game of Thrones", Year = 1996 },
                        new Book { AuthorId = 6, Genre = "Children", Title = "Pippi Långstrump", Year = 1945 },
                        new Book { AuthorId = 7, Genre = "Horror", Title = "The Call of Cthulhu", Year = 1928 },
                        new Book { AuthorId = 8, Genre = "Mystery", Title = "The Da Vinci Code", Year = 2003 },
                        new Book { AuthorId = 9, Genre = "Fantasy", Title = "Harry Potter and the Philosopher's Stone", Year = 1997 },
                        new Book { AuthorId = 10, Genre = "Crime", Title = "To Kill a Mockingbird", Year = 1960 }

                    };
                    context.Books.AddRange(books);
                    context.SaveChanges();

                    var reviews = new Review[]
                    {

                        new Review { BookId=1, Rating=1, ReviewText="Fan vad dålig.", ReviewBy = "Karl"},
                        new Review { BookId=1, Rating=3, ReviewText="Ganska bra.", ReviewBy = "Anna"},
                        new Review { BookId=10, Rating=4, ReviewText="Fan vad bra.", ReviewBy = "Bengt"},
                        new Review { BookId=10, Rating=2, ReviewText="Medelmåttig.", ReviewBy = "Sara"},
                        new Review { BookId=7, Rating=3, ReviewText="Helt okej.", ReviewBy = "Malin"},
                        new Review { BookId=6, Rating=5, ReviewText="Fan vad bra.", ReviewBy = "Anders"},
                        new Review { BookId=5, Rating=4, ReviewText="En av de bästa jag har läst.", ReviewBy = "Martina"},
                        new Review { BookId=3, Rating=1, ReviewText="Riktigt usel.", ReviewBy = "Björn"},
                        new Review { BookId=3, Rating=4, ReviewText="Kanonbra!", ReviewBy = "Mark"},
                        new Review { BookId=2, Rating=5, ReviewText="Full pott, länge sen jag läste en så bra bok.", ReviewBy = "Doris"}
                    };
                    context.Reviews.AddRange(reviews);
                    context.SaveChanges();


                }
            }
        }
    }
}
