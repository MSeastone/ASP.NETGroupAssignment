﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Uppgift_asp.net_grupp_5.Models
{
    public class Review
    {
        public int Id { get; set; }
        public int BookId { get; set; }

        [Required]
        [Display(Name = "Review By")]
        public string ReviewBy { get; set; }

        [Required]
        [Range(1, 5)]
        public int Rating { get; set; }
        public string ReviewText { get; set; }
        public Book Book { get; set; }
    }
}