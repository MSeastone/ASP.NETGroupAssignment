﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Uppgift_asp.net_grupp_5.Models
{
    public class Author
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Author Name")]
        public string AuthorName { get; set; }

        public ICollection<Book> Books { get; set; }
    }
}
