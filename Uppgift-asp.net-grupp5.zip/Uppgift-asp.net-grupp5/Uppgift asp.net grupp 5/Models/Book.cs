﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Uppgift_asp.net_grupp_5.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }

        [Display(Name = "Author ID")]
        public int AuthorId { get; set; }
        public string Genre { get; set; }
        public int Year { get; set; }

        public Author Author { get; set; }
        public ICollection<Review> Reviews { get; set; }
    }
}
