﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace Uppgift_asp.net_grupp_5.Models
{
    public class ViewModel
    {
        public Author Author { get; set; }
        public SelectList Authors { get; set; }
        public Book Book { get; set; }
        public List<Book> Books { get; set; }
        public List<Review> Reviews { get; set; }
    }
}
