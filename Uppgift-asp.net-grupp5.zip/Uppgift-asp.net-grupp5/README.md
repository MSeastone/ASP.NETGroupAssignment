# Uppgift-asp.net-grupp-5

Uppdraget gick ut på att skapa en sajt för bokrecensioner där användaren kan lägga till författare, böcker och sedan skapa bokrecensioner.
Man kan gå in på respektive författare för att se medelvärde för dennes böcker. För böckerna som ligger inne i databasen kan man även
se antalet rencensioner publicerade till den boken.

Tekniker som har använts
- ASP.NET Core MVC Web App
- Entity Framework Core
- SQL Server
- HTML
- CSS
- JavaScript
- Git

Ett arbete av grupp 5 - Louis, Madde, Simon och Johan - SUT 20
